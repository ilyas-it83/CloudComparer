For a dump of the icons from the Azure portal in SVG form, see the BONUS directory which is a peer of the Symbols directory.  Open the symbols instructions on how to convert from SVG to other formats. 

